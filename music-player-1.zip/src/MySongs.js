import React from "react";
import "./MySongs.css";

function MySongs() {
  return (
    <div className="my__songs">
      <p>Your Playlist</p>
    </div>
  );
}

export default MySongs;
