// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBuxwg95fnfLn5E7LMrZLk2qp7xElrwLFI",
  authDomain: "playlistapp1-75dcf.firebaseapp.com",
  projectId: "playlistapp1-75dcf",
  storageBucket: "playlistapp1-75dcf.appspot.com",
  messagingSenderId: "260947898451",
  appId: "1:260947898451:web:c416f0164b649ae2d2d6a6",
  measurementId: "G-H6T6TWDR9C",
};
